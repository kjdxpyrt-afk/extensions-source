apply(plugin = "tachiyomi.extension")

extension {
    name = "Komiku"
    id = "komiku"
    icon = "https://komiku.org/favicon.ico"
    description = "Komiku Indonesia manga source"
    versionCode = 1
    lang = "id"
    nsfw = false
}
